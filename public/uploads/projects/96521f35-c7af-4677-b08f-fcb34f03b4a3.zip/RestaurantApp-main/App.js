import { NavigationContainer , DarkTheme , DefaultTheme } from '@react-navigation/native';
import SplashScreen from 'react-native-splash-screen';
import { useColorScheme } from 'react-native';
import AuthStack from './src/navigation/AuthStack.tsx';
import { MenuProvider } from 'react-native-popup-menu';
import { store } from './src/store/store.ts';
import { Provider } from 'react-redux';
import { ApiProvider } from '@reduxjs/toolkit/dist/query/react';
import { apiSlice } from './src/api/ApiSlice.tsx';
import {PaperProvider} from 'react-native-paper';


SplashScreen.hide();

function StackNavigator() {
  const theme = useColorScheme();
  return (
    <ApiProvider api={apiSlice}>
      <PaperProvider>
    <Provider store={store}>
      <MenuProvider>
        <NavigationContainer independent={true} theme = {theme === 'dark' ? DarkTheme : DefaultTheme}>
          <AuthStack />
        </NavigationContainer>
      </MenuProvider>
    </Provider>
    </PaperProvider>
    </ApiProvider>
  );
}

export default function App() {
  return (
    <NavigationContainer>
      <StackNavigator />
    </NavigationContainer>
  );
}
