import AsyncStorage from '@react-native-async-storage/async-storage';

const saveData = async (data : any) : Promise<any> => {
  try {
    const filteredData =  {
      userID : data.userID,
      staffId : data.staffID,
      staffCategoryId : data.staffCategoryID,
      authCode : data.AuthCode,
      companyName : data.CompanyName,
    }
    const value = JSON.stringify(filteredData);
    await AsyncStorage.setItem('authKeys', value);
  } catch (e) {
    console.log(e);
  }
  return null;
};

const getData = async () =>{
        try {
            const jsonValue = await AsyncStorage.getItem('authKeys')
            if (jsonValue !== null){
              return JSON.parse(jsonValue);
            }
            else {
                return null;
            }
        }
        catch (e) {
            return "error";
        }
    }






export {saveData , getData};
