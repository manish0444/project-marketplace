import {
  BaseQueryFn,
  createApi,
  FetchArgs,
  fetchBaseQuery,
} from '@reduxjs/toolkit/query/react';
import {Login, ILoginResponse, ProviderData, ErrorResponseType} from '../index';

export const apiSlice = createApi({
  reducerPath: 'apiSlice',
  // to connect in local server http://10.0.2.2:5029 in mobile
  baseQuery: fetchBaseQuery({
    baseUrl: 'http://202.51.74.38:10003',
    headers: {'Content-Type': 'application/json'},
  }),
  keepUnusedDataFor: 1,
  tagTypes: ['ProviderData'],
  endpoints: builder => ({
    postLoginData: builder.mutation<ILoginResponse, Login>({
      query: body => ({
        url: `/login`,
        method: 'POST',
        body: body,
      }),
      transformErrorResponse : (response: ErrorResponseType ) =>
      response.data[0][0].errorMessage,
    }),

    getProviderData: builder.query<any, Partial<ProviderData>>({
      query: ({staffId, body}) => ({
        url: `/wcf/${staffId}`,
        method: 'POST',
        body: body,
      }),
      transformResponse: (res: any) => {
        const data = JSON.parse(res.resultValue.stringValue);
        if (Array.isArray(data.Table) && data?.Table1 === undefined) {
          return data.Table;
        } else if (data?.Table1 === undefined) {
          return [data.Table];
        } else {
          return data;
        }
      },
      providesTags: ['ProviderData'],
    }),

    postProviderData: builder.mutation<any, Partial<ProviderData>>({
      query: ({staffId, body}) => ({
        url: `/wcf/${staffId}`,
        method: 'POST',
        body: body,
      }),
      transformResponse: (res: any) => {
        const data = JSON.parse(res.resultValue.stringValue);
        if (Array.isArray(data.Table) && data?.Table1 === undefined) {
          return data.Table;
        } else if (data.Table && data?.Table1 === undefined) {
          return [data.Table];
        } else {
          return data;
        }
      },
      invalidatesTags: ['ProviderData'],
    }),
  }),
});

export const {
  usePostLoginDataMutation,
  useGetProviderDataQuery,
  usePostProviderDataMutation,
} = apiSlice;
