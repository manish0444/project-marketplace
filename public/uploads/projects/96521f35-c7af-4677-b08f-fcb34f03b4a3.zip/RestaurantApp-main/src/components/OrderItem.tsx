import React, {useMemo} from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  Dimensions,
  useColorScheme
} from 'react-native';
import FontAwesome5Icon from 'react-native-vector-icons/FontAwesome5';
import {
  Modal,
  Portal,
  Button,
  RadioButton,
  TextInput,
} from 'react-native-paper';

const windowWidth = Dimensions.get('window').width;

const OrderItem = ({data, setOrderItem, orderItem}) => {
  const [visible, setVisible] = React.useState(false);
  const showModal = () => setVisible(true);
  const hideModal = () => setVisible(false);
  const priorityItem = useMemo(() => {
    return [1, 2, 3, 4, 5];
  },[]);

  const [priority, setPriority] = React.useState(data.OrderPriority);

  const [remarks, setRemarks] = React.useState('');

  const handleEdit = () => {
    const newOrder = orderItem.map(item => {
      if (item.AccBillMasterId === data.AccBillMasterId) {
        return {
          ...item,
          OrderPriority: priority,
          Remarks: remarks,
        };
      } else {
        return item;
      }
    });
    setOrderItem(newOrder);
    hideModal();
  };

  const handleIncrease = () => {
    const newOrder = orderItem.map(item => {
      if (item.AccBillMasterId === data.AccBillMasterId && item.isPending != "False") {
        return {
          ...item,
          OrderQty: item.OrderQty + 1,
        };
      } else {
        return item;
      }
    });
    setOrderItem(newOrder);
  };

  const handleDecrease = () => {
    const newOrder = orderItem.map(item => {
      if (item.AccBillMasterId === data.AccBillMasterId && item.OrderQty > 1 && item.isPending != "False") {
        return {
          ...item,
          OrderQty: item.OrderQty - 1,
        };
      } else if (
        item.OrderQty === 1 &&
        item.AccBillMasterId === data.AccBillMasterId && item.isPending != "False"
      ) {
        return {
          ...item,
          OrderQty: 0,
        };
      } else {
        return item;
      }
    });
    const filteredOrder = newOrder.filter(item => item.OrderQty !== 0);
    setOrderItem(filteredOrder);
  };

  return (
    <View
      style={{
        backgroundColor: '#F6F6F6',
        height: 45,
        justifyContent: 'space-between',
        alignItems: 'center',
        flexDirection: 'row',
        width: windowWidth,
        paddingHorizontal: 15,
      }}>
      <Portal>
        <Modal
          visible={visible}
          onDismiss={hideModal}
          contentContainerStyle={{
            backgroundColor: 'white',
            padding: 20,
            marginHorizontal: 20,
            borderRadius: 10,
          }}>
          <View style={{justifyContent: 'center', alignItems: 'center'}}>
            <View style={{marginVertical: 10, gap: 10}}>
              <View style={{flexDirection: 'row', alignItems: 'center'}}>
                <Text style={{fontSize: 16 , color : 'black'}}>Priority : </Text>
                <View style={{flexDirection: 'row'}}>
                  {priorityItem.map((item, index) => {
                    return (
                      <View
                        key={index}
                        style={{
                          justifyContent: 'center',
                          alignItems: 'center',
                        }}>
                        <RadioButton
                          value={item}
                          status={priority === item ? 'checked' : ''}
                          onPress={() => {
                            setPriority(item);
                          }}
                        />
                        <Text style={{color :'black'}}>{item}</Text>
                      </View>
                    );
                  })}
                </View>
              </View>
              <View
                style={{flexDirection: 'row', gap: 10, alignItems: 'center'}}>
                <TextInput
                  mode="outlined"
                  label={'Remarks'}
                  value={remarks}
                  style={{width: 230, height: 40 , color : 'black'}}
                  onChangeText={text => setRemarks(text)}
                />
              </View>
            </View>
            <View
              style={{
                justifyContent: 'center',
                alignItems: 'center',
                flexDirection: 'row',
                gap: 10,
              }}>
              <Button
                mode="contained"
                buttonColor="#009B18"
                textColor='black'
                onPress={handleEdit}>
                Save
              </Button>
              <Button
                mode="contained"
                buttonColor="#BBBBBB"
                textColor="black"
                onPress={hideModal}>
                Cancel
              </Button>
            </View>
          </View>
        </Modal>
      </Portal>
      <View
        style={{gap: 15, flexDirection: 'row', flexWrap: 'warp', width: '50%'}}>
        <TouchableOpacity activeOpacity={1} onPress={showModal}>
          <FontAwesome5Icon
            name={'edit'}
            color={'#000'}
            size={15}></FontAwesome5Icon>
        </TouchableOpacity>
        <Text style={{color :'black'}}>{data?.Particular}</Text>
      </View>
      <View style={{gap: 15, flexDirection: 'row', flexWrap: 'warp' , alignItems :'center'}}>
        { data?.isPending != "False" ?<TouchableOpacity activeOpacity={1} onPress={handleDecrease}>
          <FontAwesome5Icon
            name={'minus-circle'}
            color={'red'}
            size={24}></FontAwesome5Icon>
        </TouchableOpacity>
        : <FontAwesome5Icon
        name={'lock'}
        color={'black'}
        size ={24}
        style={{marginRight : 20}}
        ></FontAwesome5Icon>
        }
        <Text style={{color :'black'}}>{data?.OrderQty}</Text>
        {data?.isPending != "False" ?   
        <TouchableOpacity activeOpacity={1} onPress={handleIncrease}>
          <FontAwesome5Icon
            name={'plus-circle'}
            color={'green'}
            size={24}></FontAwesome5Icon>
        </TouchableOpacity>
        :<View style={{marginHorizontal : 2}}></View>}
        <Text style={{color :'black'}}>Rs {data?.OrderQty * data?.Rate}</Text>
      </View>
    </View>
  );
};

export default OrderItem;
