import React from 'react';
import {
  Menu,
  MenuOptions,
  MenuOption,
  MenuTrigger,
} from 'react-native-popup-menu';
import {View, Text, TouchableOpacity , Alert} from 'react-native';
import FontAwesome5Icon from 'react-native-vector-icons/FontAwesome5';
import {useDispatch} from 'react-redux';
import {useAppSelector} from '../api/hooks';
import {cancelOrderBody} from '../constant';
import {usePostProviderDataMutation} from '../api/ApiSlice';
import { AuthState } from '../index';

const CancelOrder = ({navigation}: any) => {
  const auth = useAppSelector<AuthState>(state => state?.auth);
  const dispatch = useDispatch();
  const {KitchenOrderId} = useAppSelector(state => state.order);

  const [cancelRequest, {isLoading: canceling, error}] =
    usePostProviderDataMutation();

  const CancelObject = {
    ...cancelOrderBody,
    authenticationCode: auth.authCode,
    staffID: auth.staffId,
    oParams: {
      id: {...cancelOrderBody.oParams.id, integerValue: KitchenOrderId},
    },
  };

  const orderCancel = async () => {
    try {
      await cancelRequest({staffId: auth?.staffId, body: CancelObject}).unwrap();
      navigation.navigate(auth.companyName);
    } catch (e) {
      Alert.alert('Something went wrong');
    }
  };
  return (
    <View>
      <Menu style={{borderRadius: 20}}>
        <MenuTrigger>
          <View style={{marginRight : 16 , justifyContent : 'center' , alignItems : 'center'}}>
              <FontAwesome5Icon
                name={'ellipsis-v'}
                color={'#000'}
                size={18}></FontAwesome5Icon>
          </View>
        </MenuTrigger>
        <MenuOptions>
          <MenuOption
            onSelect={orderCancel}
            style={{backgroundColor: '#2A2A2A'}}>
            <View
              style={{
                margin: 10,
                flexDirection: 'row',
                gap: 10,
                alignItems: 'center',
              }}>
              <Text style={{fontSize: 12, color: '#ffffff'}}>Cancel Order</Text>
            </View>
          </MenuOption>
        </MenuOptions>
      </Menu>
    </View>
  );
};

export default CancelOrder;
