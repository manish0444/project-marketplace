import React from 'react';
import {
  Menu,
  MenuOptions,
  MenuOption,
  MenuTrigger,
} from 'react-native-popup-menu';
import {View, Text, TouchableOpacity} from 'react-native';
import {useDispatch} from 'react-redux';
import {apiSlice} from '../api/ApiSlice';
import AsyncStorage from '@react-native-async-storage/async-storage';
import {useAppSelector} from '../api/hooks';
import {removeAuthData} from '../store/Authslice';
import FontAwesome5Icon from 'react-native-vector-icons/FontAwesome5';

const MenuPop = ({navigation}: any) => {
  const auth = useAppSelector(state => state.auth);
  const dispatch = useDispatch();
  const logOut = async () => {
    try {
      await AsyncStorage.removeItem('authKeys');
    } catch (e) {
      console.log(e);
    }
    dispatch(removeAuthData());
  };
  return (
    <View>
      <Menu style={{borderRadius: 20}}>
        <MenuTrigger>
          <View style={{marginRight:16 , justifyContent : 'center' , alignItems : 'center'}}>
              <FontAwesome5Icon
                name={'ellipsis-v'}
                color={'#000'}
                size={18}></FontAwesome5Icon>
            </View>
        </MenuTrigger>
        <MenuOptions>
          <MenuOption onSelect={logOut} style={{backgroundColor: '#2A2A2A'}}>
            <View
              style={{
                margin: 10,
                flexDirection: 'row',
                gap: 10,
                alignItems: 'center',
              }}>
              <Text style={{fontSize: 12, color: '#ffffff'}}>Log out</Text>
            </View>
          </MenuOption>
        </MenuOptions>
      </Menu>
      </View>
  );
};

export default MenuPop;
