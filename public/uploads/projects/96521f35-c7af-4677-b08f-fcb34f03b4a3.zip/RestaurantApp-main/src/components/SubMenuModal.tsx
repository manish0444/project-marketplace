import React, {useEffect, useState} from 'react';
import {
  View,
  Text,
  Dimensions,
  TouchableOpacity,
  ScrollView,
} from 'react-native';
import {Modal, Portal} from 'react-native-paper';
import FontAwesome5Icon from 'react-native-vector-icons/FontAwesome5';
import MenuItem from './MenuItem';

const SubMenuModal = ({
  data,
  visible,
  setVisible,
  filteredMenu,
  Menu,
  setMenu,
  selectedMenu ,
  setSelectedMenu
}) => {
  const showModal = () => setVisible(true);
  const hideModal = () => setVisible(false);
  useEffect(() => {
    if (selectedMenu !== null){
    const subMenu = Menu?.reduce((item, current) => {
      if (current.name === selectedMenu) {
        item.push(current);
      }
      return item;
    }, []);
    setMenu(subMenu);
    }
  }, [selectedMenu]);


  return (
    <View>
      <TouchableOpacity
        activeOpacity={1}
        onPress={() => {
          showModal();
        }}>
        <FontAwesome5Icon
          name={'list'}
          color={'#000'}
          size={24}></FontAwesome5Icon>
      </TouchableOpacity>
      <Portal>
        <Modal
          visible={visible}
          onDismiss={() => {
            hideModal();
          }}
          contentContainerStyle={{
            backgroundColor: 'white',
            padding: 8,
            marginHorizontal: 20,
            borderRadius: 20,
          }}>
          <View style={{justifyContent: 'center', alignItems: 'center'}}>
            <Text style={{fontSize: 26, color: 'black', textAlign: 'center'}}>
              Menu
            </Text>
          </View>
          <MenuItem
            data={data}
            setMenu={setMenu}
            filteredData={filteredMenu}
            selectedMenu={selectedMenu}
            setSelectedMenu={setSelectedMenu}
            setVisible={setVisible}
          />
        </Modal>
      </Portal>
    </View>
  );
};

export default SubMenuModal;
