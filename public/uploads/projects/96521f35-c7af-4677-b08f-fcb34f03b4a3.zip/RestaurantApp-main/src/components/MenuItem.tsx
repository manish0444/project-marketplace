import React from 'react';
import {
  View,
  Text,
  Dimensions,
  ScrollView,
  TouchableOpacity,
} from 'react-native';

const windowWidth = Dimensions.get('window').width;

const MenuItem = ({
  data,
  setMenu,
  filteredData,
  selectedMenu,
  setSelectedMenu,
  setVisible,
}) => {
  return (
    <View style={{marginHorizontal: 2, gap: 10, paddingHorizontal: 3 , height: '90%' }}>
      <ScrollView>
        <View style={{flexDirection: 'row', flexWrap: 'wrap' }}>
          {filteredData?.map((name, index) => {
            return (
              <View
                key={index}
                style={{marginHorizontal: 5, flexDirection: 'row', gap: 5 ,marginVertical : 4}}>
                <TouchableOpacity
                  style={{
                    backgroundColor:
                      selectedMenu === name ? '#009B18' : '#D8D7D7',
                    height: 95,
                    width: 95,
                    justifyContent: 'center',
                    alignItems: 'center',
                    padding: 10,
                    borderRadius: 6,
                  }}
                  onPress={() => {
                    setSelectedMenu(name);
                    setMenu(data);
                    setVisible(false);
                  }}
                  disabled={selectedMenu === name ? true : false}>
                  <Text
                    style={{color: selectedMenu === name ? 'white' : 'black'}}>
                    {name}
                  </Text>
                </TouchableOpacity>
              </View>
            );
          })}
        </View>
      </ScrollView>
    </View>
  );
};

export default MenuItem;
