import React, {useState, useEffect} from 'react';
import {View} from 'react-native';
import {Picker} from '@react-native-picker/picker';
import {apiBody} from '../constant';
import {useAppSelector} from '../api/hooks';
import {useGetProviderDataQuery} from '../api/ApiSlice';
import {useAppDispatch} from '../api/hooks';
import {updateState} from '../store/Kitchenslice';
const KitchenPicker = () => {
  const dispatch = useAppDispatch();
  const {staffId, authCode} = useAppSelector(state => state.auth);
  const KitchenData = {
    ...apiBody,
    staffId: staffId,
    authenticationCode: authCode,
    smethod: 'GetKitchenDynamic/RestaurantDataProvider',
  };
  const {data, isLoading, error} = useGetProviderDataQuery({
    staffId: staffId,
    body: KitchenData,
  });
  const [selectedKitchen, setSelectedKitchen] = useState();
  // useEffect(() => {
  //   if (data !== undefined) {
  //     dispatch(updateState({Id: data[0].Id, Name: data[0].Name}));
  //   }
  // }, []);

  return (
    <View style={{width: 200}}>
      <Picker
        selectedValue={selectedKitchen}
        onValueChange={(item, index) => {
          setSelectedKitchen(item);
          dispatch(updateState({Id: item.Id, Name: item.Name}));
        }}>
        {data?.map((item, index) => {
          return <Picker.Item key={index} label={item.Name} value={item} />;
        })}
      </Picker>
    </View>
  );
};

export default KitchenPicker;
