import React, {useState} from 'react';
import {
  Dimensions,
  View,
  TouchableOpacity,
  Text,
  ScrollView,
} from 'react-native';

import {foodObject} from '../constant';

const windowWidth = Dimensions.get('window').width;

const FoodItem = ({data, setOrderItem, orderItem}) => {
  const handleOrder = () => {
    const isExist = orderItem.find(
      item => item.AccBillMasterId === data.particularId && item.isPending != "False",
    );
    if (isExist) {
      const newOrder = orderItem.map(item => {
        if (item.AccBillMasterId === data.particularId && item.isPending != "False") {
          return {
            ...item,
            OrderQty: item.OrderQty + 1,
          };
        } else {
          return item;
        }
      });
      setOrderItem(newOrder);
    } else {
      const order = {
        ...foodObject,
        OrderQty: 1,
        Particular: data.particular,
        Rate: data.rate,
        AccBillMasterId: data.particularId,
      };
      setOrderItem([...orderItem, order]);
    }
  };
  return (
    <TouchableOpacity
      style={{
        height: 90,
        width: windowWidth-20,
        justifyContent: 'center',
        alignItems: 'center',
        padding: 10,
        borderRadius: 6,
        backgroundColor: '#F6F6F6',
      }}
      onPress={handleOrder}>
      <View style={{justifyContent: 'center', alignItems: 'center'}}>
        <Text style={{color: 'black'}}>{data.particular}</Text>
        <Text style={{color: 'black', fontSize: 18}}>Rs {data.rate}</Text>
      </View>
    </TouchableOpacity>
  );
};

export default FoodItem;
