import React from 'react';

import {View, TouchableOpacity, Dimensions, Text} from 'react-native';

import {useAppDispatch} from '../api/hooks';
import {updateKitchenOrderId} from '../store/OrderSlice';

const windowWidth = Dimensions.get('window').width;

const TableButton = ({data, navigation}) => {
  const dispatch = useAppDispatch();
  const handlePress = () => {
    if (data.KitchenOrderId === '0') {
      navigation.navigate('Table', data);
    } else {
      dispatch(updateKitchenOrderId({KitchenOrderId: data?.KitchenOrderId}));
      navigation.navigate('UpdatedTable', data);
    }
  };

  return (
    <TouchableOpacity
      style={{
        backgroundColor:
          data.KitchenOrderId !== '0' && data.pendingCount > data.readyCount
            ? '#8a0900'
            : data.KitchenOrderId !== '0' &&
              data.pendingCount <= data.readyCount
            ? '#00a300'
            : '#F6F6F6',
        height: 120,
        width: 120,
        justifyContent: 'flex-start',
        alignItems: 'center',
        padding: 10,
        borderRadius: 6,
      }}
      activeOpacity={0.4}
      onPress={handlePress}>
      <Text style={{color: data.KitchenOrderId === '0' ? 'black' : 'white'}}>
        {data.name}
      </Text>
      <Text style={{color: data.KitchenOrderId === '0' ? 'black' : 'white'}}>
        ({data.totalCount === '0' ? 'Empty' : `Occupied`})
      </Text>
      <View
        style={{marginTop: 5, justifyContent: 'center', alignItems: 'center'}}>
        <Text style={{color: data.KitchenOrderId === '0' ? 'black' : 'white'}}>
          {data?.KitchenOrderId !== '0'
            ? `Order Id: ${data.KitchenOrderId}`
            : ''}
        </Text>
        <Text style={{color: data.KitchenOrderId === '0' ? 'black' : 'white'}}>
          {data?.KitchenOrderId !== '0'
            ? `${data?.readyCount} / ${data?.pendingCount}`
            : ''}
        </Text>
        <Text style={{color: data.KitchenOrderId === '0' ? 'black' : 'white'}}>{data?.KitchenOrderId !== '0'
            ? `R / P`
            : ''}</Text>
      </View>
    </TouchableOpacity>
  );
};

export default TableButton;
