import React, {useState, useEffect} from 'react';
import {
  View,
  Text,
  ScrollView,
  Dimensions,
  FlatList,
  TouchableOpacity,
  Alert,
} from 'react-native';
import OrderItem from '../components/OrderItem';
import {ActivityIndicator, Button, Searchbar} from 'react-native-paper';
import FontAwesome5Icon from 'react-native-vector-icons/FontAwesome5';
import FoodItem from '../components/FoodItem';
import {useAppSelector} from '../api/hooks';
import {
  useGetProviderDataQuery,
  usePostProviderDataMutation,
} from '../api/ApiSlice';
import {apiBody, orderObject, foodObject, postOrderBody} from '../constant';
import SubMenuModal from '../components/SubMenuModal';


const windowWidth = Dimensions.get('window').width;
const windowHeight = Dimensions.get('window').height;

const UpdateOrderPage = ({route, navigation}) => {
  const [orderItem, setOrderItem] = useState(currentOrderData);
  const [selectedMenu, setSelectedMenu] = useState<any>();
  const [totalPrice , setTotalPrice] = useState<number>();
  const [visible, setVisible] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [orderData, setOrderData] = useState();
  const tableData = route.params;
  const kitchen = useAppSelector(state => state.kitchen);
  const {staffId, authCode, companyName , userID} = useAppSelector(state => state.auth);
  const {menu : menuData} = useAppSelector(state => state.menu);

  const getOrderData = {
    ...apiBody,
    oParams: {
      ...apiBody.oParams,
      whereCondition: {
        ...apiBody.oParams.whereCondition,
        stringValue: ` AND KOD.KitchenOrderId = ${tableData?.KitchenOrderId}`,
      },
    },
    staffId: staffId,
    authenticationCode: authCode,
    smethod: 'GetOrderDetailDynamic/RestaurantDataProvider',
  };

  const {data: currentOrderData, isLoading: isCurrentOrder} =
    useGetProviderDataQuery({
      staffId: staffId,
      body: getOrderData,
    });

    const filteredMenu = [
      ...new Set(
        menuData?.map(item => {
          return item.name;
        }),
      ),
    ];

  const [Menu, setMenu] = useState<string[]>(menuData);

  useEffect(() => {
    if (currentOrderData) {
      const filteredOrder = currentOrderData?.map(item => {
        return {
          ...item,
          OrderQty: parseInt(item.OrderQty),
        };
      });
      setOrderItem(filteredOrder);
    }
  }, [isCurrentOrder]);


  // const [order, setOrder] = useState<any>(orderObject);
  const [updateOrder, {isLoading: submitting, error}] =
    usePostProviderDataMutation();

  const handleUpdate = () => {
    setOrderData({
      ...postOrderBody,
      sMethod: 'InsertUpdateOrder/RestaurantDataProvider',
      authenticationCode: authCode,
      staffID: staffId,
      oParams: {
        OrderDataJson: {
          stringValue: JSON.stringify({
            ...orderObject,
            UserID : userID,
            Id: tableData?.KitchenOrderId,
            RestaurantTableId: tableData?.id,
            RestaurantTableName: tableData?.name,
            OrderDateTime: new Date(),
            KitchenId: kitchen.Id,
            KitchenOrderDetail: [...orderItem],
          }),
        },
      },
    });
  };

  useEffect(() => {
    if (orderData) {
      if (orderItem.length === 0) {
        return Alert.alert('Please select atleast one item');
      } else {
        const postingData = async () => {
          const res = await updateOrder({
            staffId: staffId,
            body: orderData,
          });
          if (!error) {
            navigation.navigate(companyName);
          }
        };
        postingData();
      }
    }
  }, [orderData]);

  useEffect(() => {
    if (searchQuery === '' || searchQuery === null || searchQuery ===  undefined) {
      if (selectedMenu !== (null || undefined)){
        const subMenu = menuData?.reduce((item, current) => {
          if (current.name === selectedMenu) {
            item.push(current);
          }
          return item;
        }, []);
        setMenu(subMenu);
      } else {
      setMenu(menuData);
      }
    } else {
    const filteredData = Menu?.filter(item => {
      return item.particular.toLowerCase().includes(searchQuery.toLowerCase());
    });
    setMenu(filteredData);
    }
  }, [searchQuery]);



  useEffect(()=>{

    const grandTotal = orderItem?.reduce((partialSum :number, item :any) => partialSum + (item.OrderQty * item.Rate) , 0);

    setTotalPrice(grandTotal);

  },[orderItem , isCurrentOrder])

  return (
    <View
      style={{
        width: windowWidth,
        height: windowHeight,
        flex: 1,
        backgroundColor: '#DFDFDF',
      }}>
        <View
        style={{
          marginVertical: 10,
          flexDirection: 'row',
          justifyContent: 'space-around',
          alignItems: 'center',
        }}>
        <Searchbar
          placeholder="Search"
          style={{width: windowWidth - 120}}
          onChangeText={setSearchQuery}
          value={searchQuery}
        />
        <SubMenuModal
          visible={visible}
          setVisible={setVisible}
          filteredMenu={filteredMenu}
          Menu={Menu}
          setMenu={setMenu}
          data={menuData}
          selectedMenu = {selectedMenu}
          setSelectedMenu = {setSelectedMenu}
        />
        <View>
          <TouchableOpacity activeOpacity={0.4} onPress={() => {
            setSelectedMenu(null);
            setMenu(menuData);
          }
          }>
            <FontAwesome5Icon
              name={'undo'}
              color={'#000'}
              size={24}></FontAwesome5Icon>
          </TouchableOpacity>
        </View>
      </View>
      <ScrollView style={{backgroundColor: '#DFDFDF', margin: 6}} nestedScrollEnabled={true}>
        <View
          style={{
            width: windowWidth,
            flexDirection: 'row',
            flexWrap: 'wrap',
            marginHorizontal: 2,
            gap: 10,
            paddingHorizontal: 3,
          }}>
          <FlatList data = {Menu} renderItem={({item , index}) => <FoodItem key={index} data={item} setOrderItem={setOrderItem} orderItem={orderItem}/>} 
          keyExtractor={item => item.particularId}
          contentContainerStyle={{
            flexGrow: 0,
            gap :10,
            }}/>
        </View>
      </ScrollView>
        
      <View
        style={{
          justifyContent: 'space-between',
          flexDirection: 'row',
          alignItems: 'center',
          height: '6.5%',
          backgroundColor: '#009B18',
          paddingHorizontal: 15,
        }}>
        <Text style={{color: 'white'}}>
          {tableData?.KitchenOrderId !== '0'
            ? `Order No : ${tableData?.KitchenOrderId}`
            : 'New Order'}
        </Text>
        <Text style={{color : 'white'}}>{selectedMenu}</Text>
      </View>

      <View
        style={{
          justifyContent: 'flex-end',
          alignItems: 'center',
          height: '35%',
          backgroundColor: '#DFDFDF',
        }}>
        <ScrollView style={{gap: 1}}>
        {isCurrentOrder ? <View style={{marginVertical : 8}}><ActivityIndicator /></View>:
          orderItem?.map((item, index) => {
            return (
              <OrderItem
                key={index}
                data={item}
                orderItem={orderItem}
                setOrderItem={setOrderItem}
              />
            );
          })}
        </ScrollView>
      </View>
      <View
        style={{
          justifyContent: 'space-between',
          flexDirection: 'row',
          alignItems: 'center',
          height: '6.5%',
          backgroundColor: '#009B18',
          paddingHorizontal: 15,
        }}>
        <Text style={{color : 'white'}}>Total</Text>
        <Text style={{color: 'white'}}>Rs {totalPrice}</Text>
      </View>
      <View style={{marginVertical: 8, gap: 8}}>
      <View
          style={{
            justifyContent: 'center',
            gap: 10,
            flexDirection: 'row',
          }}>
          <Button
            mode="contained"
            buttonColor="#009B18"
            onPress={handleUpdate}
            textColor='black'
            disabled={submitting}>
            Update
          </Button>
          <Button
            mode="contained"
            buttonColor="#BBBBBB"
            textColor="black"
            onPress={() => {
              navigation.navigate(companyName);
            }}>
            Cancel
          </Button>
        </View>
      </View>
    </View>
  );
};

export default UpdateOrderPage;
