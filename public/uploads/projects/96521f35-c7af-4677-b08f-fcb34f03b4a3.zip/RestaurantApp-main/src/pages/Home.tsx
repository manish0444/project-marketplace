import React, {useState, useEffect, useCallback} from 'react';
import {View, Text, Dimensions, ScrollView, RefreshControl} from 'react-native';
import TableButton from '../components/TableButton';
import {useGetProviderDataQuery} from '../api/ApiSlice';
import {useAppSelector} from '../api/hooks';
import {apiBody} from '../constant/apiBody';
import {useAppDispatch} from '../api/hooks';
import {apiSlice} from '../api/ApiSlice';
import { addMenu } from '../store/Menuslice';
import { ActivityIndicator } from 'react-native-paper';
import { Props } from '../index';
const windowWidth = Dimensions.get('window').width;
const windowHeight = Dimensions.get('window').height;

const Home = ({navigation} : Props) => {
  const [refresh, setRefresh] = useState(false);
  const dispatch = useAppDispatch();
  const onRefresh = useCallback(() => {
    setRefresh(true);
    dispatch(apiSlice.util.resetApiState());
    setTimeout(() => {
      setRefresh(false);
    }, 1000);
  }, []);

  const {staffId, authCode} = useAppSelector(state => state.auth);
  const RestaurantTable = {
    ...apiBody,
    staffID: staffId,
    authenticationCode: authCode,
    smethod: 'GetOccupiedRestaurantTableDynamic/RestaurantDataProvider',
  };
  const {data, isLoading} = useGetProviderDataQuery({
    staffId: staffId,
    body: RestaurantTable,
  });
  const MenuData = {
    ...apiBody,
    staffId: staffId,
    authenticationCode: authCode,
    smethod: 'GetActiveBillItemDynamicById/RestaurantDataProvider',
  };
  const {data : menuData, isLoading : menuLoading} = useGetProviderDataQuery({
    staffId: staffId,
    body: MenuData,
  });


  useEffect(()=>{
    dispatch(addMenu(menuData));
  },[menuLoading])
  


  return (
    <ScrollView
      style={{backgroundColor: '#DFDFDF' , flex : 1}}
      refreshControl={
        <RefreshControl refreshing={refresh} onRefresh={onRefresh} />
      }>
      <View
        style={{
          width: windowWidth,
          margin: 8,
          flexDirection: 'row',
          gap: 5,
          flexWrap: 'wrap',
        }}>
          {menuLoading ? <View style={{justifyContent : 'flex-start' , alignItems : 'center' , height : windowHeight , width : windowWidth}}><ActivityIndicator size={'large'} /></View> :
        data?.map((item : any, index : number) => {
          return (
            <TableButton key={index} data={item} navigation={navigation} />
          );
        })
      }
      </View>
    </ScrollView>
  );
};

export default Home;
