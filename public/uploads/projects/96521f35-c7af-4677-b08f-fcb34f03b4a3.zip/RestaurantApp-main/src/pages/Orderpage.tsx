import React, {useState, useEffect} from 'react';
import {
  View,
  Text,
  ScrollView,
  Dimensions,
  FlatList,
  TouchableOpacity,
  Alert,
} from 'react-native';
import OrderItem from '../components/OrderItem';
import {Button, Searchbar} from 'react-native-paper';
import FontAwesome5Icon from 'react-native-vector-icons/FontAwesome5';
import FoodItem from '../components/FoodItem';
import {useAppSelector} from '../api/hooks';
import {
  usePostProviderDataMutation,
} from '../api/ApiSlice';
import {orderObject, postOrderBody} from '../constant';
import SubMenuModal from '../components/SubMenuModal';
import { Props } from '../index';

const windowWidth = Dimensions.get('window').width;
const windowHeight = Dimensions.get('window').height;


const OrderPage = ({route, navigation} : Props) => {
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [visible, setVisible] = useState<boolean>(false);
  const [orderData, setOrderData] = useState<any>();
  const [orderItem, setOrderItem] = useState([]);
  const [selectedMenu, setSelectedMenu] = useState<any>();
  const [totalPrice , setTotalPrice] = useState<number>();
  const tableData = route.params;
  const {staffId, authCode, companyName , userID} = useAppSelector(state => state.auth); 
  const kitchen = useAppSelector(state => state.kitchen);
  const {menu : menuData} = useAppSelector(state => state.menu);
  const filteredMenu = [
    ...new Set(
      menuData?.map((item : any )=> {
        return item.name;
      }),
    ),
  ];

  
  const [Menu, setMenu] = useState<string[]>(menuData);
  

  const [postOrder, {isLoading: submitting, error}] =
    usePostProviderDataMutation();


  const handleSubmit = () => {
    setOrderData({
      ...postOrderBody,
      sMethod: 'InsertUpdateOrder/RestaurantDataProvider',
      authenticationCode: authCode,
      staffID: staffId,
      oParams: {
        OrderDataJson: {
          stringValue: JSON.stringify({
            ...orderObject,
            UserId :  userID,
            RestaurantTableId: tableData?.id,
            RestaurantTableName: tableData?.name,
            OrderDateTime: new Date(),
            KitchenId: kitchen?.Id,
            KitchenOrderDetail: [...orderItem],
          }),
        },
      },
    });
  };

  useEffect(() => {
    if (orderData) {
      if (orderItem.length === 0) {
        Alert.alert('Please add some item');
      } else {
        const postingData = async () => {
          const res = await postOrder({
            staffId: staffId,
            body: orderData,
          });
        };
        if (!error) {
          navigation.navigate(companyName);
        }
        postingData();
      }
    }
  }, [orderData]);

  useEffect(() => {
    if (searchQuery === '' || searchQuery === null || searchQuery ===  undefined) {
      if (selectedMenu !== (null || undefined)){
        const subMenu = menuData?.reduce((item, current) => {
          if (current.name === selectedMenu) {
            item.push(current);
          }
          return item;
        }, []);
        setMenu(subMenu);
      } else {
      setMenu(menuData);
      }
    } else {
    const filteredData = Menu?.filter(item => {
      return item.particular.toLowerCase().includes(searchQuery.toLowerCase());
    });
    setMenu(filteredData);
    }
  }, [searchQuery]);




  useEffect(()=>{

    const grandTotal = orderItem?.reduce((partialSum :number, item :any) => partialSum + (item.OrderQty * item.Rate) , 0);

    setTotalPrice(grandTotal);

  },[orderItem])
  return (
    <View
      style={{
        width: windowWidth,
        height: windowHeight,
        backgroundColor: '#DFDFDF',
        flex:1
      }}>
      <View
        style={{
          marginVertical: 10,
          flexDirection: 'row',
          justifyContent: 'space-around',
          alignItems: 'center',
        }}>
        <Searchbar
          placeholder="Search"
          style={{width: windowWidth - 120}}
          onChangeText={setSearchQuery}
          value={searchQuery}
        />
        <SubMenuModal
          visible={visible}
          setVisible={setVisible}
          filteredMenu={filteredMenu}
          Menu={Menu}
          setMenu={setMenu}
          data={menuData}
          selectedMenu = {selectedMenu}
          setSelectedMenu = {setSelectedMenu}
        />
        <View>
          <TouchableOpacity activeOpacity={0.4} onPress={() => {
            setSelectedMenu(null);
            setSearchQuery('');
            setMenu(menuData);
          }
          }>
            <FontAwesome5Icon
              name={'undo'}
              color={'#000'}
              size={24}></FontAwesome5Icon>
          </TouchableOpacity>
        </View>
      </View>
      {/* <View style={{width: windowWidth}}>
        <MenuItem
          data={menu}
          setMenu={setMenu}
          Menu={Menu}
        />
      </View> */}
      
      <ScrollView style={{backgroundColor: '#DFDFDF', margin: 6}} nestedScrollEnabled={true}>
        <View
          style={{
            width: windowWidth,
            flexDirection: 'row',
            flexWrap: 'wrap',
            marginHorizontal: 2,
            gap: 10,
            paddingHorizontal: 3,
          }}>
          <FlatList data = {Menu} renderItem={({item , index}) => <FoodItem key={index} data={item} setOrderItem={setOrderItem} orderItem={orderItem}/>} 
          keyExtractor={item => item.particularId}
          contentContainerStyle={{
            flexGrow: 0,
            gap :10,
            }}/>
        </View>
      </ScrollView>
      <View
        style={{
          justifyContent: 'space-between',
          flexDirection: 'row',
          alignItems: 'center',
          height: '6.5%',
          backgroundColor: '#009B18',
          paddingHorizontal: 15,
        }}>
        <Text style={{color: 'white'}}>
          {tableData?.KitchenOrderId !== '0'
            ? tableData?.KitchenOrderId
            : 'New Order'}
        </Text>
        <Text style={{color : 'white'}}>{selectedMenu}</Text>
      </View>

      <View
        style={{
          justifyContent: 'flex-end',
          alignItems: 'center',
          height: '35%',
          backgroundColor: '#DFDFDF',
        }}>
        <ScrollView style={{gap: 1}}>
          {orderItem?.map((item, index) => {
            return (
              <OrderItem
                key={index}
                data={item}
                orderItem={orderItem}
                setOrderItem={setOrderItem}
              />
            );
          })}
        </ScrollView>
      </View>
      <View
        style={{
          justifyContent: 'space-between',
          flexDirection: 'row',
          alignItems: 'center',
          height: '6.5%',
          backgroundColor: '#009B18',
          paddingHorizontal: 15,
        }}>
        <Text style={{color : 'white'}}>Total</Text>
        <Text style={{color: 'white'}}>Rs:  {totalPrice}</Text>
      </View>
      <View style={{marginVertical: 8, gap: 8}}>
        <View
          style={{
            justifyContent: 'center',
            gap: 10,
            flexDirection: 'row',
          }}>
          <Button
            mode="contained"
            buttonColor="#009B18"
            textColor='black'
            onPress={handleSubmit}
            disabled={submitting}>
            Save
          </Button>
          <Button
            mode="contained"
            buttonColor="#BBBBBB"
            textColor="black"
            onPress={() => {
              navigation.navigate(companyName);
            }}>
            Cancel
          </Button>
        </View>
      </View>
    </View>
  );
};

export default OrderPage;
