import {TextInput, Button} from 'react-native-paper';
import React, {useState, useEffect} from 'react';
import { useTheme } from 'react-native-paper';
import {
  Text,
  View,
  Image,
  StyleSheet,
  Dimensions,
} from 'react-native';
import {saveData , getData} from '../api/CacheData';
import {
  usePostLoginDataMutation,
} from '../api/ApiSlice';
import {addAuthData} from '../store/Authslice';
import {useAppDispatch} from '../api/hooks';
import { Snackbar } from 'react-native-paper';

const windowWidth = Dimensions.get('window').width;

const Login :React.FC = () => {
  const dispatch = useAppDispatch();
  const [visible, setVisible] = React.useState(false);
  const [post, {isLoading, error}] = usePostLoginDataMutation();
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [domain, setDomain] = useState('');
  const [authData, setAuthData] = useState<any>();
  const [showPassword, setShowPassword] = useState(true);


  const onDismissSnackBar = () => setVisible(false);

  useEffect(() => {
    if (authData !== undefined && authData !== null) {
      saveData(authData);
    }
  }, [authData]);

  useEffect(()=>{
    if(error){
      setVisible(true);
    }
  },[isLoading])

  useEffect(()=>{
    getData().then(res=>{
      if(res !== null){
        dispatch(addAuthData({
          staffId: res?.staffId,
          staffCategoryId: res?.staffCategoryId,
          authCode: res?.authCode,
          isSignedIn: true,
          companyName: res?.companyName,
          userID : res?.userID
        }))
      }
    })
  },[]);





  const login = (e: any) => {
    e.preventDefault();
    post({
      username: username,
      password: password,
      domain: domain,
      rememberMe: true,
    })
      .unwrap()
      .then(res => {
        setAuthData(res),
          dispatch(
            addAuthData({
              staffId: res?.staffID,
              staffCategoryId: res?.staffCategoryID,
              authCode: res?.AuthCode,
              isSignedIn: true,
              companyName: res?.CompanyName,
              userID : res?.userID
            }),
          );
      });
  };

  return (
    <View
      style={{
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
      }}>
        <Snackbar
        visible={visible}
        onDismiss={onDismissSnackBar}
        duration={4000}>
          <Text style={{color : 'white'}}>{error as string}</Text>
        </Snackbar>
 
      <View
        style={{
          justifyContent: 'center',
          alignItems: 'center',
          padding: 5,
          width: 500,
        }}>
        <Image
          style={styles.img}
          source={require('../../assets/logo.png')}
        />
        <View style={{margin: 10, gap: 15}}>
          <TextInput
            label="Username"
            onChangeText={setUsername}
            style={styles.textinput}
            activeOutlineColor={'#EC5800'}
            mode={'outlined'}
          />
          <TextInput
            label="Password"
            mode={'outlined'}
            secureTextEntry={showPassword}
            activeOutlineColor={'#EC5800'}
            style={styles.textinput}
            onChangeText={setPassword}
            right={<TextInput.Icon icon="eye" color={'#EC5800'} onPress={()=> setShowPassword(!showPassword)}/>}
          />
          <TextInput
            label="Domain"
            mode={'outlined'}
            activeOutlineColor={'#EC5800'}
            style={styles.textinput}
            onChangeText={setDomain}
          />
        </View> 
        <View style={{margin: 10}}>
          <Button
            mode="contained"
            buttonColor="#EC5800"
            textColor='black'
            onPress={e => login(e)}
            loading={isLoading}
            disabled={isLoading}>
            Login
          </Button>
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  img: {
    width: 100,
    height: 100,
  },
  textinput: {
    width: windowWidth - 100,
  },
  loginbtn: {
    borderRadius: 10,
    backgroundColor: '#EC5800',
    paddingHorizontal: 20,
    width: 200,
    paddingVertical: 10,
  },
});

export default Login;
