import React from 'react';
import {createNativeStackNavigator} from '@react-navigation/native-stack';
import Login from '../pages/Login';
import AppStack from './AppStack';
import {StackNavigatorParamList} from '../index';
import {useAppSelector} from '../api/hooks';

const Stack = createNativeStackNavigator<StackNavigatorParamList>();

const AuthStack = () => {
  const auth = useAppSelector(state => state.auth);

  return (
    <Stack.Navigator screenOptions={{headerShown: false}}>
      {auth?.isSignedIn === true ? (
        <Stack.Screen name={'AppStack'} component={AppStack}></Stack.Screen>
      ) : (
        <Stack.Screen name={'Login'} component={Login}></Stack.Screen>
      )}
    </Stack.Navigator>
  );
};

export default AuthStack;
