import React from 'react';
import {View} from 'react-native';
import {NativeStackScreenProps} from '@react-navigation/native-stack';
import {StackNavigatorParamList} from '../index';
import {createNativeStackNavigator} from '@react-navigation/native-stack';
import {useAppSelector} from '../api/hooks';
import Home from '../pages/Home';
import MenuPop from '../components/MenuPop';
import CancelOrder from '../components/CancelOrder';
import UpdateOrderPage from '../pages/UpdateOrderPage';
import KitchenPicker from '../components/KitchenPicker';
import OrderPage from '../pages/Orderpage';
import { Props } from '../index';


const Stack = createNativeStackNavigator<any>();

const AppStack: React.FC<Props> = ({navigation}) => {
  const authData = useAppSelector(state => state.auth);
  console.log(authData);
  return (
    <Stack.Navigator
      screenOptions={{
        unmontOnBlur: true,
      }}
      >
      <Stack.Screen
        name={authData?.companyName ?? 'Home'}
        component={Home}
        options={{
          headerStyle: {
            backgroundColor: '#538CE9',
          },
          headerTintColor: '#fff',
          headerTitleStyle: {
            fontWeight: 'bold',
          },
          headerRight: () => <MenuPop navigation={navigation} />,
        }}
      />
      <Stack.Screen
        name={'Table'}
        component={OrderPage}
        options={({route}) => ({
          headerBackButtonMenuEnabled: true,
          headerBackVisible: true,
          headerStyle: {
            backgroundColor: '#538CE9',
          },
          headerTintColor: '#fff',
          headerTitleStyle: {
            fontWeight: 'bold',
          },
          title: route.params?.name,
          headerRight: () => {
            return (
              <View
                style={{
                  flexDirection: 'row',
                  justifyContent: 'center',
                  alignItems: 'center',
                  gap: 10,
                }}>
                <KitchenPicker />
                <CancelOrder navigation={navigation} />
              </View>
            );
          },
        })}></Stack.Screen>
      <Stack.Screen
        name={'UpdatedTable'}
        component={UpdateOrderPage}
        options={({route}) => ({
          headerBackButtonMenuEnabled: true,
          headerBackVisible: true,
          headerStyle: {
            backgroundColor: '#538CE9',
          },
          headerTintColor: '#fff',
          headerTitleStyle: {
            fontWeight: 'bold',
          },
          title: route.params?.name,
          headerRight: () => {
            return (
              <View
                style={{
                  flexDirection: 'row',
                  justifyContent: 'center',
                  alignItems: 'center',
                  gap: 10,
                }}>
                <KitchenPicker />
                <CancelOrder navigation={navigation} />
              </View>
            );
          },
        })}></Stack.Screen>
    </Stack.Navigator>
  );
};

export default AppStack;
