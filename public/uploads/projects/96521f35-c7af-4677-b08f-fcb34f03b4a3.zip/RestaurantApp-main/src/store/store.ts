import { configureStore } from '@reduxjs/toolkit';
import Authslice from './Authslice';
import Kitchenslice from './Kitchenslice';
import OrderSlice from './OrderSlice';
import { apiSlice } from '../api/ApiSlice';
import Menuslice from './Menuslice';

export const store = configureStore({
  reducer: {
    auth : Authslice,
    kitchen : Kitchenslice,
    order : OrderSlice,
    menu : Menuslice,
    [apiSlice.reducerPath] : apiSlice.reducer,
  },
  middleware: (getDefaultMiddleware) =>
    getDefaultMiddleware({
      serializableCheck: false,
    }).concat(apiSlice.middleware),
});


export type RootState = ReturnType<typeof store.getState>
export type AppDispatch = typeof store.dispatch