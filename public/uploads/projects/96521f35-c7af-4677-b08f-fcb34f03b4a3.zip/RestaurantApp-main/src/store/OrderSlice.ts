import { createSlice } from '@reduxjs/toolkit';
import type { PayloadAction } from '@reduxjs/toolkit';
import type { RootState } from './store';


const initialState = {
    KitchenOrderId : null,
};

export const OrderSlice = createSlice({
  name: 'order',
  initialState,
  reducers: {
    updateKitchenOrderId: (state, action : PayloadAction<AuthState>) => {
      state.KitchenOrderId = action.payload.KitchenOrderId;
    },
  },
});

export const { updateKitchenOrderId } = OrderSlice.actions;

export default OrderSlice.reducer;
