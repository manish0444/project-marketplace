import { createSlice } from '@reduxjs/toolkit';
import type { PayloadAction } from '@reduxjs/toolkit';
import type { RootState } from './store';
import { AuthState } from '../index';


const initialState : AuthState = {
    staffId : null,
    staffCategoryId : null ,
    authCode : null,
    isSignedIn : false ,
    companyName : null,
    userID : null 
};

export const authSlice = createSlice({
  name: 'auth',
  initialState,
  reducers: {
    addAuthData: (state, action : PayloadAction<AuthState>) => {
      state.staffId = action.payload.staffId;
      state.authCode = action.payload.authCode;
      state.staffCategoryId = action.payload.staffCategoryId;
      state.isSignedIn = action.payload.isSignedIn;
      state.companyName = action.payload.companyName;
      state.userID = action.payload.userID;
    },
    removeAuthData : (state) =>{
      state.staffId = null ;
      state.authCode =null ;
      state.staffCategoryId =null ;
      state.isSignedIn =false;
      state.companyName = null;
      state.userID = null;
    }
  },
});

export const { addAuthData, removeAuthData } = authSlice.actions;

export default authSlice.reducer;
