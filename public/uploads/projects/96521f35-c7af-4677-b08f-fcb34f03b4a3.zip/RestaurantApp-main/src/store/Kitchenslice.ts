import { createSlice } from '@reduxjs/toolkit';
import type { PayloadAction } from '@reduxjs/toolkit';
import type { RootState } from './store';


const initialState = {
    Id : null,
    Name : null ,
};

export const kitchenSlice = createSlice({
  name: 'kitchen',
  initialState,
  reducers: {
    updateState: (state, action : PayloadAction<any>) => {
      state.Id = action.payload.Id;
      state.Name = action.payload.Name;
    },
  },
});

export const { updateState } = kitchenSlice.actions;

export default kitchenSlice.reducer;
