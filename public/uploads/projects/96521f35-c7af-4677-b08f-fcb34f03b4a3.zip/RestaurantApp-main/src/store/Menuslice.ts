import { createSlice } from '@reduxjs/toolkit';
import type { PayloadAction } from '@reduxjs/toolkit';
import type { RootState } from './store';


const initialState : any = {
    menu : null
};

export const MenuSlice = createSlice({
  name: 'menu',
  initialState,
  reducers: {
    addMenu: (state, action : PayloadAction<any>) => {
      state.menu = action.payload;
    },
  },
});

export const { addMenu } = MenuSlice.actions;

export default MenuSlice.reducer;
