export const cancelOrderBody = {
  rProvider: 0,
  sMethod: 'CancelKitchenOrder/RestaurantDataProvider',
  sConnectionID: null,
  authenticationCode: null,
  staffID: 0,
  oParams: {
    id: {
      listStr: null,
      listIntegers: null,
      listDouble: null,
      integerValue: 0,
      longValue: null,
      stringValue: null,
      floatValue: null,
      doubleValue: null,
      decimalValue: null,
      dateValue: null,
      DTRGObject: null,
      buffer: null,
      bufferSize: null,
    },
  },
};
