export const orderObject = {
  Id: 0,
  KitchenId: 2,
  KitchenName: null,
  RestaurantTableId: 1,
  RestaurantTableName: null,
  OrderDateTime: null,
  OrderPriority: 1,
  IsPending: true,
  IsCancelled: false,
  IsPacking: false,
  IsPaid: false,
  PaidDateTime: null,
  UserId: null || 0,
  Remarks: '',
  CustomerName: '',
  CustomerContact: '',
  KitchenOrderDetail: [],
};

export const foodObject = {
  Id: 0,
  KitchenOrderId: 0,
  AccBillMasterId: null,
  Particular: null,
  OrderQty: null,
  IsPending: true,
  Rate: null,
};
