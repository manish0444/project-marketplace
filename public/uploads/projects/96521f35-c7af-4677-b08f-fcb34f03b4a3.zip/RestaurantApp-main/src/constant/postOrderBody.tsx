export const postOrderBody = {
  rProvider: 0,
  sMethod: null,
  sConnectionID: null,
  authenticationCode: null,
  staffID: 0,
  oParams: {
    OrderDataJson: {
      listStr: null,
      listIntegers: null,
      listDouble: null,
      integerValue: 0,
      longValue: null,
      stringValue: null,
      floatValue: null,
      doubleValue: null,
      decimalValue: null,
      dateValue: null,
      DTRGObject: null,
      buffer: null,
      bufferSize: null,
    },
  },
};
