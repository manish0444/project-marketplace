import type { NativeStackScreenProps } from '@react-navigation/native-stack';

type RootStackParamList = {
    Home : undefined;
}

export type Props = NativeStackScreenProps<RootStackParamList, 'Home'>;

export interface ErrorResponseType{
    status : number ,
    data : [[
        error : {
            errorMessage : string ,
            exception : string | null, 
        }
    ]]
}

export interface AuthState{
    staffId : string | number | null,
    isSignedIn : boolean ,
    staffCategoryId : string | number | null ,
    authCode : string | null,
    companyName : string | null,
    userId : string  | null,
}


export type StackNavigatorParamList ={
    Login : undefined , 
    AppStack : undefined
}

export interface Login {
    username : string ,
    password : string ,
    domain : string ,
    rememberMe : boolean
}

export interface ILoginResponse{
    userID	:	string ,
    userName	:	string ,
    userPassword	:	string ,
    staffID	:	string | number ,
    userRoleID	:	string ,
    associateWithCompany	:	string ,
    personalFileSize	:	string ,
    authorizedDepartment	:	string ,
    DeptID	:	string,
    staffCategoryID	:	string,
    firstName	:	string,
    MiddleName	:	string,
    LastName	:	string,
    DepartmentName	:	string,
    StaffCategoryName	:	string,
    loginTime	:	string, 
    IsSupervisor	:	string ,
    thumbPath	:	string ,
    CurrentNepaliDate	:	string,
    CurrentFY	:	string,
    isOPDDoctor	:	string,
    companyLogo	:	string,
    AuthCode	:	string,
    CompanyName	:	string,
    CompanyType	:	string,
    CompanyLogo	:	string,
}

export interface ProviderData {
    data:{
    method : string
    }
    staffId : string | number | null ,
    body : {

    }

}

export interface KitchenState{
    Id : string | number | null,
    Name : string | null ,
}