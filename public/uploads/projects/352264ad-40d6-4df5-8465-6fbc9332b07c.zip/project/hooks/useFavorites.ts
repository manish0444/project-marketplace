import { useState, useEffect } from 'react';
import { Platform } from 'react-native';

// In a real app, you would use AsyncStorage or similar for persistence
// import AsyncStorage from '@react-native-async-storage/async-storage';

export function useFavorites() {
  const [favorites, setFavorites] = useState<string[]>([]);
  
  // Mock loading favorites from storage
  useEffect(() => {
    // In a real app, you would load from AsyncStorage
    // const loadFavorites = async () => {
    //   try {
    //     const storedFavorites = await AsyncStorage.getItem('favorites');
    //     if (storedFavorites) {
    //       setFavorites(JSON.parse(storedFavorites));
    //     }
    //   } catch (error) {
    //     console.error('Error loading favorites:', error);
    //   }
    // };
    
    // loadFavorites();
    
    // Mock data for prototype
    setFavorites([
      "Your smile must be a black hole because my heart can't escape its gravity",
      "If we were socks, we'd make a perfect pair"
    ]);
  }, []);
  
  const saveFavorites = async (newFavorites: string[]) => {
    // In a real app, you would save to AsyncStorage
    // try {
    //   await AsyncStorage.setItem('favorites', JSON.stringify(newFavorites));
    // } catch (error) {
    //   console.error('Error saving favorites:', error);
    // }
    
    // Just update state for the prototype
    setFavorites(newFavorites);
    
    // Provide haptic feedback on platforms that support it
    if (Platform.OS !== 'web') {
      try {
        // This would require importing Haptics
        // await Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      } catch (error) {
        console.error('Error with haptics:', error);
      }
    }
  };
  
  const toggleFavorite = (line: string) => {
    const exists = favorites.includes(line);
    let newFavorites;
    
    if (exists) {
      newFavorites = favorites.filter(fav => fav !== line);
    } else {
      newFavorites = [...favorites, line];
    }
    
    saveFavorites(newFavorites);
  };
  
  const isFavorite = (line: string) => {
    return favorites.includes(line);
  };
  
  return {
    favorites,
    toggleFavorite,
    isFavorite
  };
}