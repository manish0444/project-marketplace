// --- Configuration ---
// WARNING: NEVER embed API keys directly in client-side code for production applications.
// This key should be stored securely on a server or backend environment variable
// and accessed via a dedicated API endpoint you create.
const GEMINI_API_KEY = process.env.GEMINI_API_KEY || 'AIzaSyDixzMshGog-bt-Ne20eU2h8FEQRUIc3Io'; // Load from environment or replace *temporarily* for testing ONLY.
const API_BASE_URL = 'https://generativelanguage.googleapis.com/v1beta'; // Use v1beta or v1 as appropriate
const MODEL_NAME = 'models/gemini-1.5-flash-latest'; // Or 'gemini-pro', etc. Use a specific version if needed.
const API_ENDPOINT_FLASH = `${API_BASE_URL}/${MODEL_NAME}:generateContent?key=${GEMINI_API_KEY}`;

// --- Interfaces for better Type Safety (Optional but recommended) ---
interface GeminiPart {
  text: string;
}

interface GeminiContent {
  role: 'user' | 'model';
  parts: GeminiPart[];
}

interface GeminiCandidate {
  content: GeminiContent;
  // Add other potential fields like finishReason, safetyRatings, etc. if needed
}

interface GeminiResponse {
  candidates?: GeminiCandidate[];
  // Add promptFeedback if needed
  error?: { // Structure for potential API error response
    code: number;
    message: string;
    status: string;
  };
}

interface GeminiRequest {
    systemInstruction?: { parts: GeminiPart[] };
    contents: GeminiContent[];
    generationConfig?: {
        maxOutputTokens?: number;
        temperature?: number;
        topP?: number; // Example of other config options
        topK?: number; // Example of other config options
        candidateCount?: number; // Might request multiple candidates directly from API
    };
}


/**
 * Generates flirty lines based on user input using the Gemini API.
 *
 * @param prompt - The user's core request or context for the flirty lines.
 * @param count - The number of flirty lines to generate. Defaults to 1.
 * @returns A promise that resolves to a string containing the generated flirty line(s),
 * often separated by newlines if count > 1, or an error message.
 */
export async function getFlirtyLines(prompt: string, count: number = 1): Promise<string> {
  if (!GEMINI_API_KEY || GEMINI_API_KEY === 'YOUR_API_KEY_HERE') {
      console.error("API Key not configured. Please set the GEMINI_API_KEY.");
      return "Error: API Key not configured.";
  }

  // System prompt guides the AI's persona and style
  const systemPrompt = `You are FlirtMaster AI, an expert assistant generating modern, creative, and witty flirty lines relevant to Gen Z.
    - Keep responses brief, authentic, and respectful.
    - Avoid clichés and cheesy pickup lines.
    - Use contemporary slang and terms like 'rizz' naturally where appropriate.
    - Adapt the tone based on the user's prompt.
    - Generate exactly ${count} distinct flirty line(s). If generating multiple, present them as a numbered list.`;

  // Structure the payload according to the Gemini REST API format
  const requestBody: GeminiRequest = {
    systemInstruction: {
       parts: [{ text: systemPrompt }]
    },
    contents: [
      { role: "user", parts: [{ text: `Generate ${count} flirty line(s) based on this context or request: "${prompt}"` }] }
      // Note: No need for the model priming turn when using systemInstruction
    ],
    generationConfig: {
        maxOutputTokens: count * 60, // Adjust token limit based on expected count
        temperature: 0.85, // Slightly higher temp for more creativity
        // candidateCount: count > 1 ? count : undefined // Alternatively, ask API for multiple candidates, though parsing differs
    }
  };

  try {
    console.log("Sending request to Gemini:", JSON.stringify(requestBody, null, 2)); // Log request for debugging

    const response = await fetch(API_ENDPOINT_FLASH, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(requestBody),
    });

    const data: GeminiResponse = await response.json();
    console.log("Received response from Gemini:", JSON.stringify(data, null, 2)); // Log response for debugging


    if (!response.ok || data.error) {
      const errorMessage = data.error?.message || `API request failed with status ${response.status}`;
      console.error('API Error:', response.status, data.error || await response.text()); // Log full error text if possible
      throw new Error(errorMessage);
    }

    // Extract the generated text - check standard location first
    let generatedText = data.candidates?.[0]?.content?.parts?.[0]?.text;

    // Handle cases where the response might be empty or malformed
    if (!generatedText) {
        // Fallback: Check if the API provided multiple candidates (if candidateCount was used)
        if (data.candidates && data.candidates.length > 0) {
            generatedText = data.candidates.map((candidate, index) =>
                `${index + 1}. ${candidate.content?.parts?.[0]?.text || ''}`
            ).join('\n').trim();
        }
    }

    return generatedText || "I couldn't think of anything right now. Maybe try a different angle?";

  } catch (error: any) {
    console.error('Error generating flirty lines:', error);
    // Provide a user-friendly error message, avoid exposing internal details
    return `Failed to get flirty lines: ${error.message || 'Please try again later.'}`;
  }
}


/**
 * Analyzes conversation text and provides suggestions using the Gemini API.
 * Note: This function uses a text-only model (gemini-flash) and does not process images.
 *
 * @param conversationText - The text of the conversation needing analysis or response suggestions.
 * @returns A promise that resolves to a string containing suggestions or analysis.
 */
export async function analyzeConversation(conversationText: string): Promise<string> {
    if (!GEMINI_API_KEY || GEMINI_API_KEY === 'YOUR_API_KEY_HERE') {
        console.error("API Key not configured. Please set the GEMINI_API_KEY.");
        return "Error: API Key not configured.";
    }
    if (!conversationText || conversationText.trim() === "") {
        return "Please provide some conversation text to analyze.";
    }

    console.warn("analyzeConversation: Image analysis is not performed by this function using the text-only model.");

    const systemPrompt = `You are ConvoHelper AI, a supportive assistant providing suggestions for text conversations.
        - Your goal is to help users maintain engaging, respectful, and authentic conversations.
        - Provide specific, actionable suggestions based *directly* on the provided conversation text.
        - Keep suggestions concise and easy to understand.
        - Use modern, relatable language suitable for Gen Z, but prioritize clarity.
        - Focus on suggesting potential replies, identifying conversation tone, or suggesting next steps.`;

    const userPrompt = `Analyze the following conversation snippet and suggest some potential next messages or observations. Keep it casual, engaging, and authentic:

        --- Conversation Text ---
        ${conversationText}
        --- End Conversation Text ---

        What are some good ways to respond or things to notice?`;

    const requestBody: GeminiRequest = {
        systemInstruction: {
           parts: [{ text: systemPrompt }]
        },
        contents: [
          { role: "user", parts: [{ text: userPrompt }] }
        ],
        generationConfig: {
            maxOutputTokens: 250, // Allow for more detailed suggestions
            temperature: 0.7,
        }
    };

    try {
        console.log("Sending request to Gemini:", JSON.stringify(requestBody, null, 2));
        const response = await fetch(API_ENDPOINT_FLASH, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(requestBody),
        });

        const data: GeminiResponse = await response.json();
        console.log("Received response from Gemini:", JSON.stringify(data, null, 2));


        if (!response.ok || data.error) {
            const errorMessage = data.error?.message || `API request failed with status ${response.status}`;
            console.error('API Error:', response.status, data.error || await response.text());
            throw new Error(errorMessage);
        }

        const generatedText = data.candidates?.[0]?.content?.parts?.[0]?.text;

        return generatedText || "I couldn't analyze this effectively right now. Please try again.";

    } catch (error: any) {
        console.error('Error analyzing conversation:', error);
        return `Failed to analyze conversation: ${error.message || 'Please try again later.'}`;
    }
}

/*
 * Helper function to convert image URI to base64.
 * Kept for reference. To use with a Vision model (e.g., gemini-pro-vision) via REST API,
 * you would fetch the base64 data using this function and include it in the 'contents' array:
 * {
 * "role": "user",
 * "parts": [
 * { "text": "Describe this image:" },
 * { "inlineData": { "mimeType": "image/jpeg", "data": base64ImageData } } // Adjust mimeType as needed
 * ]
 * }
 */
async function getImageDataAsBase64(uri: string): Promise<string> {
    try {
        const response = await fetch(uri);
        if (!response.ok) {
            throw new Error(`Failed to fetch image: ${response.status} ${response.statusText}`);
        }
        const blob = await response.blob();
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.onloadend = () => {
                // Return only the base64 part, without the data: URL prefix
                const base64String = (reader.result as string)?.split(',')[1];
                if (base64String) {
                    resolve(base64String);
                } else {
                    reject(new Error('Failed to read image data as base64.'));
                }
            };
            reader.onerror = (error) => reject(error || new Error('FileReader error'));
            reader.readAsDataURL(blob);
        });
    } catch (error) {
        console.error('Error converting image to base64:', error);
        throw new Error(`Failed to process image URI: ${error instanceof Error ? error.message : String(error)}`);
    }
}

// --- How to Handle User Requests like "another", "5 more", "edit" ---
/*
 * The functions above (`getFlirtyLines`, `analyzeConversation`) are designed to perform
 * a specific API call based on the parameters they receive.
 *
 * Handling user interactions like:
 * - "Give me a flirty line" -> Call `getFlirtyLines("some context", 1)`
 * - "Give me another one" -> Call `getFlirtyLines("some context", 1)` again (potentially with modified context if needed)
 * - "Give me 5 lines about..." -> Call `getFlirtyLines("about...", 5)`
 * - "Make it better" or "Edit that" -> This is more complex. You might:
 * 1. Get the previous response.
 * 2. Construct a *new* prompt for the AI, including the previous response and the request for improvement.
 * e.g., `Improve this flirty line: '[previous line]'. Make it funnier.`
 * 3. Call `getFlirtyLines` with this new detailed prompt.
 *
 * This interaction logic belongs in the part of your application that handles user input
 * (e.g., your UI event handlers, chatbot logic, command parser), *not* within these core API functions.
 * That layer decides *which* function to call and *what parameters* (prompt, count) to pass based on the user's request.
 */