import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Image,
  ScrollView,
  ActivityIndicator,
  Platform,
} from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import * as ImageManipulator from 'expo-image-manipulator';
import * as Haptics from 'expo-haptics';
import { Camera, Copy, Trash, Upload } from 'lucide-react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { SafeAreaView } from 'react-native-safe-area-context';
import { analyzeConversation } from '@/services/aiService';
import { useTheme } from '@/context/ThemeContext';
import Header from '@/components/Header';

export default function AnalyzeScreen() {
  const [image, setImage] = useState<string | null>(null);
  const [analyzing, setAnalyzing] = useState(false);
  const [analysis, setAnalysis] = useState<string | null>(null);
  const { theme } = useTheme();
  const isDark = theme === 'dark';

  const requestGalleryPermission = async () => {
    const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (status !== 'granted') {
      alert('Sorry, we need camera roll permissions to make this work!');
      return false;
    }
    return true;
  };

  const requestCameraPermission = async () => {
    const { status } = await ImagePicker.requestCameraPermissionsAsync();
    if (status !== 'granted') {
      alert('Sorry, we need camera permissions to make this work!');
      return false;
    }
    return true;
  };

  const pickImage = async () => {
    if (Platform.OS !== 'web') {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    }
    
    const hasPermission = await requestGalleryPermission();
    if (!hasPermission) return;

    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsEditing: true,
      quality: 0.8,
    });

    if (!result.canceled && result.assets && result.assets.length > 0) {
      const manipResult = await ImageManipulator.manipulateAsync(
        result.assets[0].uri,
        [{ resize: { width: 1000 } }],
        { compress: 0.7, format: ImageManipulator.SaveFormat.JPEG }
      );
      
      setImage(manipResult.uri);
      setAnalysis(null);
    }
  };

  const takePicture = async () => {
    if (Platform.OS !== 'web') {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    }
    
    const hasPermission = await requestCameraPermission();
    if (!hasPermission) return;

    const result = await ImagePicker.launchCameraAsync({
      allowsEditing: true,
      quality: 0.8,
    });

    if (!result.canceled && result.assets && result.assets.length > 0) {
      const manipResult = await ImageManipulator.manipulateAsync(
        result.assets[0].uri,
        [{ resize: { width: 1000 } }],
        { compress: 0.7, format: ImageManipulator.SaveFormat.JPEG }
      );
      
      setImage(manipResult.uri);
      setAnalysis(null);
    }
  };

  const analyzeImage = async () => {
    if (!image) return;
    
    if (Platform.OS !== 'web') {
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    }
    
    setAnalyzing(true);
    setAnalysis(null);
    
    try {
      const result = await analyzeConversation(image);
      setAnalysis(result);
    } catch (error) {
      console.error('Error analyzing image:', error);
      setAnalysis('Sorry, I could not analyze this conversation. Please try again with a clearer image.');
    } finally {
      setAnalyzing(false);
    }
  };

  const clearImage = () => {
    if (Platform.OS !== 'web') {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    }
    
    setImage(null);
    setAnalysis(null);
  };

  const copyToClipboard = (text: string) => {
    if (Platform.OS !== 'web') {
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    }
    // In a real app, you'd use Clipboard.setString(text)
    console.log('Copied to clipboard:', text);
  };

  return (
    <SafeAreaView style={[styles.container, isDark ? styles.containerDark : styles.containerLight]}>
      <Header title="Analyze Chat" />
      
      <ScrollView style={styles.scrollView} contentContainerStyle={styles.scrollContent}>
        <Text style={[styles.instructionText, isDark ? styles.textDark : styles.textLight]}>
          Upload a screenshot of your conversation to get suggestions on what to say next
        </Text>
        
        {image ? (
          <View style={styles.imageContainer}>
            <Image source={{ uri: image }} style={styles.image} />
            
            <View style={styles.imageActions}>
              <TouchableOpacity
                style={[styles.actionButton, styles.deleteButton, isDark ? styles.deleteButtonDark : styles.deleteButtonLight]}
                onPress={clearImage}
              >
                <Trash size={20} color={isDark ? '#F44336' : '#D32F2F'} />
              </TouchableOpacity>
              
              <TouchableOpacity
                style={[styles.actionButton, styles.analyzeButton]}
                onPress={analyzeImage}
                disabled={analyzing}
              >
                <LinearGradient
                  colors={['#7C4DFF', '#6200EE']}
                  style={styles.analyzeButtonGradient}
                >
                  {analyzing ? (
                    <ActivityIndicator color="#FFFFFF" size="small" />
                  ) : (
                    <Text style={styles.analyzeButtonText}>Analyze</Text>
                  )}
                </LinearGradient>
              </TouchableOpacity>
            </View>
          </View>
        ) : (
          <View style={styles.uploadContainer}>
            <LinearGradient
              colors={isDark ? ['#2D2D2D', '#1E1E1E'] : ['#F5F5F5', '#EEEEEE']}
              style={styles.uploadArea}
            >
              <Upload size={48} color={isDark ? '#BB86FC' : '#6200EE'} />
              <Text style={[styles.uploadText, isDark ? styles.textDark : styles.textLight]}>
                Upload or take a screenshot
              </Text>
              
              <View style={styles.uploadButtons}>
                <TouchableOpacity
                  style={[styles.button, isDark ? styles.buttonDark : styles.buttonLight]}
                  onPress={pickImage}
                >
                  <Text style={[styles.buttonText, isDark ? styles.buttonTextDark : styles.buttonTextLight]}>
                    Choose from Library
                  </Text>
                </TouchableOpacity>
                
                <TouchableOpacity
                  style={[styles.button, styles.primaryButton]}
                  onPress={takePicture}
                >
                  <LinearGradient
                    colors={['#7C4DFF', '#6200EE']}
                    style={styles.primaryButtonGradient}
                  >
                    <Camera size={16} color="#FFFFFF" style={styles.buttonIcon} />
                    <Text style={styles.primaryButtonText}>Take Photo</Text>
                  </LinearGradient>
                </TouchableOpacity>
              </View>
            </LinearGradient>
          </View>
        )}
        
        {analysis && (
          <View style={[styles.resultContainer, isDark ? styles.resultContainerDark : styles.resultContainerLight]}>
            <Text style={[styles.resultTitle, isDark ? styles.textDark : styles.textLight]}>
              Suggested Responses:
            </Text>
            <Text style={[styles.resultText, isDark ? styles.textDark : styles.textLight]}>
              {analysis}
            </Text>
            
            <TouchableOpacity
              style={styles.copyButton}
              onPress={() => copyToClipboard(analysis)}
            >
              <Copy size={16} color={isDark ? '#BB86FC' : '#6200EE'} style={styles.copyIcon} />
              <Text style={[styles.copyText, isDark ? { color: '#BB86FC' } : { color: '#6200EE' }]}>
                Copy to clipboard
              </Text>
            </TouchableOpacity>
          </View>
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  containerLight: {
    backgroundColor: '#F5F5F5',
  },
  containerDark: {
    backgroundColor: '#121212',
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    padding: 16,
  },
  instructionText: {
    fontSize: 16,
    marginBottom: 24,
    textAlign: 'center',
    fontFamily: 'Outfit-Regular',
  },
  textLight: {
    color: '#212121',
  },
  textDark: {
    color: '#FFFFFF',
  },
  uploadContainer: {
    marginVertical: 16,
  },
  uploadArea: {
    borderRadius: 16,
    padding: 32,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 2,
    borderColor: '#E0E0E0',
    borderStyle: 'dashed',
  },
  uploadText: {
    fontSize: 18,
    marginVertical: 16,
    fontFamily: 'Outfit-SemiBold',
  },
  uploadButtons: {
    width: '100%',
    marginTop: 16,
  },
  button: {
    borderRadius: 8,
    paddingVertical: 12,
    paddingHorizontal: 16,
    marginVertical: 8,
    alignItems: 'center',
    justifyContent: 'center',
    elevation: 1,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 1,
  },
  buttonLight: {
    backgroundColor: '#FFFFFF',
    borderWidth: 1,
    borderColor: '#E0E0E0',
  },
  buttonDark: {
    backgroundColor: '#2D2D2D',
    borderWidth: 1,
    borderColor: '#333333',
  },
  buttonText: {
    fontSize: 16,
    fontFamily: 'Outfit-SemiBold',
  },
  buttonTextLight: {
    color: '#6200EE',
  },
  buttonTextDark: {
    color: '#BB86FC',
  },
  primaryButton: {
    overflow: 'hidden',
  },
  primaryButtonGradient: {
    flex: 1,
    width: '100%',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 12,
    paddingHorizontal: 16,
  },
  primaryButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontFamily: 'Outfit-SemiBold',
  },
  buttonIcon: {
    marginRight: 8,
  },
  imageContainer: {
    marginVertical: 16,
    borderRadius: 16,
    overflow: 'hidden',
  },
  image: {
    width: '100%',
    height: 400,
    resizeMode: 'contain',
    backgroundColor: '#000',
  },
  imageActions: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    padding: 8,
  },
  actionButton: {
    borderRadius: 8,
    paddingVertical: 12,
    paddingHorizontal: 16,
    alignItems: 'center',
    justifyContent: 'center',
  },
  deleteButton: {
    borderWidth: 1,
  },
  deleteButtonLight: {
    borderColor: '#D32F2F',
  },
  deleteButtonDark: {
    borderColor: '#F44336',
  },
  analyzeButton: {
    flex: 1,
    marginLeft: 8,
    overflow: 'hidden',
  },
  analyzeButtonGradient: {
    width: '100%',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 12,
    paddingHorizontal: 16,
    borderRadius: 8,
  },
  analyzeButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontFamily: 'Outfit-SemiBold',
  },
  resultContainer: {
    marginVertical: 16,
    padding: 16,
    borderRadius: 16,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  resultContainerLight: {
    backgroundColor: '#FFFFFF',
  },
  resultContainerDark: {
    backgroundColor: '#1E1E1E',
  },
  resultTitle: {
    fontSize: 18,
    fontFamily: 'Outfit-Bold',
    marginBottom: 8,
  },
  resultText: {
    fontSize: 16,
    lineHeight: 24,
    fontFamily: 'Outfit-Regular',
  },
  copyButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 16,
    padding: 8,
  },
  copyIcon: {
    marginRight: 8,
  },
  copyText: {
    fontSize: 14,
    fontFamily: 'Outfit-SemiBold',
  },
});