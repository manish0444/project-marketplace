import React, { useState, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  FlatList,
  ActivityIndicator,
  Keyboard,
  Platform,
  // Removed unused import: Keyboard
} from 'react-native';
import * as Haptics from 'expo-haptics';
import * as Clipboard from 'expo-clipboard'; // Import Expo Clipboard
import { Send, Copy, Heart, HeartOff } from 'lucide-react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { SafeAreaView } from 'react-native-safe-area-context';
import { getFlirtyLines } from '@/services/aiService';
import { Message } from '@/types/chat';
import { useFavorites } from '@/hooks/useFavorites';
import { useTheme } from '@/context/ThemeContext';
import Header from '@/components/Header';

export default function ChatScreen() {
  const [input, setInput] = useState('');
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      content: 'Hey there! What kind of flirty line are you looking for today?',
      sender: 'ai',
      timestamp: new Date(),
    },
  ]);
  const [isLoading, setIsLoading] = useState(false);
  const { favorites, toggleFavorite, isFavorite } = useFavorites();
  const { theme } = useTheme();
  const flatListRef = useRef<FlatList>(null);
  const isDark = theme === 'dark';

  const handleSend = async () => {
    if (!input.trim()) return;

    if (Platform.OS !== 'web') {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    }

    const userMessage: Message = {
      id: Date.now().toString(),
      content: input,
      sender: 'user',
      timestamp: new Date(),
    };

    setMessages((prevMessages) => [...prevMessages, userMessage]);
    setInput('');
    setIsLoading(true);

    // Automatically scroll to the end after sending a message
    flatListRef.current?.scrollToEnd({ animated: true });

    try {
      const response = await getFlirtyLines(input);

      const aiMessage: Message = {
        id: (Date.now() + 1).toString(),
        content: response,
        sender: 'ai',
        timestamp: new Date(),
      };

      setMessages((prevMessages) => [...prevMessages, aiMessage]);
    } catch (error) {
      console.error('Error getting flirty lines:', error);

      const errorMessage: Message = {
        id: (Date.now() + 1).toString(),
        content: "Sorry, I couldn't generate lines right now. Please try again later.",
        sender: 'ai',
        timestamp: new Date(),
        isError: true,
      };

      setMessages((prevMessages) => [...prevMessages, errorMessage]);
    } finally {
      setIsLoading(false);
      // Ensure scroll happens even after AI response/error
      setTimeout(() => flatListRef.current?.scrollToEnd({ animated: true }), 100);
    }
  };

  // Make copyToClipboard async to use await with Clipboard
  const copyToClipboard = async (text: string) => {
    if (Platform.OS !== 'web') {
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    }
    try {
      await Clipboard.setStringAsync(text);
      // Optional: Add a toast or alert confirmation
      // alert('Copied to clipboard!');
      console.log('Copied to clipboard:', text);
    } catch (e) {
      console.error('Failed to copy text to clipboard', e);
      // Optional: Notify user of failure
      // alert('Failed to copy text.');
    }
  };

  const renderMessage = ({ item }: { item: Message }) => {
    const isAi = item.sender === 'ai';
    const fav = isAi && !item.isError; // Renamed variable, was unused otherwise

    return (
      <View style={[
        styles.messageContainer,
        isAi ?
          (isDark ? styles.aiMessageDark : styles.aiMessageLight) :
          (isDark ? styles.userMessageDark : styles.userMessageLight)
      ]}>
        <Text style={[
          styles.messageText, // Base style first
          // Apply AI or User text color styles
          isAi ?
            (isDark ? styles.aiTextDark : styles.aiTextLight) : // Use theme-specific AI text color
            styles.userText,
          // Apply error style override if applicable
          item.isError && styles.errorText
        ]}>
          {item.content}
        </Text>

        {/* Actions only for non-error AI messages */}
        {isAi && !item.isError && (
          <View style={styles.messageActions}>
            <TouchableOpacity
              style={styles.actionButton}
              onPress={() => copyToClipboard(item.content)} // Directly call the updated function
            >
              {/* Use theme-aware color for the Copy icon */}
              <Copy size={16} color={isDark ? '#BB86FC' : '#6200EE'} />
            </TouchableOpacity>
            <TouchableOpacity
              style={styles.actionButton}
              onPress={() => toggleFavorite(item.content)}
            >
              {isFavorite(item.content) ? (
                <Heart size={16} color="#F44336" fill="#F44336" />
              ) : (
                 // Use theme-aware color for the HeartOff icon
                <HeartOff size={16} color={isDark ? '#BB86FC' : '#6200EE'} />
              )}
            </TouchableOpacity>
          </View>
        )}

        <Text style={[styles.timestamp, isDark ? styles.timestampDark : styles.timestampLight]}>
          {item.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
        </Text>
      </View>
    );
  };

  return (
    <SafeAreaView style={[styles.container, isDark ? styles.containerDark : styles.containerLight]}>
      <Header title="FlirtMaster AI" showFavorites={true} />

      <FlatList
        ref={flatListRef}
        data={messages}
        renderItem={renderMessage}
        keyExtractor={(item) => item.id}
        contentContainerStyle={styles.messagesContainer}
        // Removed redundant onContentSizeChange/onLayout, handle scroll in handleSend
      />

      <View style={[styles.inputContainer, isDark ? styles.inputContainerDark : styles.inputContainerLight]}>
        <TextInput
          style={[styles.input, isDark ? styles.inputDark : styles.inputLight]}
          value={input}
          onChangeText={setInput}
          placeholder="Ask for flirty lines..."
          placeholderTextColor={isDark ? '#9E9E9E' : '#757575'}
          multiline
        />
        <TouchableOpacity
          style={[
            styles.sendButton,
            (!input.trim() || isLoading) && styles.sendButtonDisabled // Disable if loading OR no input
          ]}
          onPress={handleSend}
          disabled={!input.trim() || isLoading}
        >
          <LinearGradient
            // Use slightly different gradient colors for consistency if needed
            colors={isDark ? ['#CF9FFF', '#BB86FC'] : ['#7C4DFF', '#6200EE']}
            style={styles.sendButtonGradient}
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 1 }}
          >
            {isLoading ? (
              <ActivityIndicator color="#FFFFFF" size="small" />
            ) : (
              <Send size={20} color="#FFFFFF" />
            )}
          </LinearGradient>
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  containerLight: {
    backgroundColor: '#F5F5F5', // Lighter gray background
  },
  containerDark: {
    backgroundColor: '#121212', // Standard dark background
  },
  messagesContainer: {
    paddingHorizontal: 16,
    paddingBottom: 16, // Add padding at the bottom of the list
    flexGrow: 1, // Ensure it can grow to allow scrolling
  },
  messageContainer: {
    marginVertical: 8,
    padding: 16,
    borderRadius: 20,
    maxWidth: '85%', // Slightly increase max width
    elevation: 1,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 1,
  },
  aiMessageLight: {
    backgroundColor: '#FFFFFF', // White background for AI in light mode
    borderTopLeftRadius: 4,     // Sharp corner top-left
    alignSelf: 'flex-start',    // Align left
  },
  aiMessageDark: {
    backgroundColor: '#1E1E1E', // Darker gray for AI in dark mode
    borderTopLeftRadius: 4,
    alignSelf: 'flex-start',
  },
  userMessageLight: {
    backgroundColor: '#6200EE', // User messages purple in light mode
    borderTopRightRadius: 4,    // Sharp corner top-right
    alignSelf: 'flex-end',      // Align right
  },
  userMessageDark: {
    backgroundColor: '#BB86FC', // Lighter purple for user in dark mode
    borderTopRightRadius: 4,
    alignSelf: 'flex-end',
  },
  messageText: {
    fontSize: 16,
    lineHeight: 24,
    fontFamily: 'Outfit-Regular', // Ensure font is loaded
    marginRight: 40, // Add margin to prevent overlap with actions/timestamp
  },
  // Specific AI text colors based on theme
  aiTextLight: {
    color: '#6200EE', // Use the theme's primary variant color (Indigo/Purple)
  },
  aiTextDark: {
    color: '#BB86FC', // Use the theme's lighter purple color
  },
  userText: {
    color: '#FFFFFF', // White text for user messages (background provides contrast)
  },
  errorText: {
    color: '#F44336', // Red for error messages
    fontStyle: 'italic', // Make errors visually distinct
  },
  timestamp: {
    fontSize: 10,
    position: 'absolute', // Position timestamp absolutely
    bottom: 5,
    right: 10,
    fontFamily: 'Outfit-Regular', // Ensure font is loaded
  },
  timestampLight: {
    color: '#9E9E9E', // Gray timestamp in light mode
  },
  timestampDark: {
    color: '#757575', // Slightly lighter gray timestamp in dark mode
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'flex-end', // Align items to bottom for multiline input
    paddingHorizontal: 12, // Adjust padding
    paddingVertical: 8,
    borderTopWidth: 1,
  },
  inputContainerLight: {
    backgroundColor: '#FFFFFF',
    borderTopColor: '#E0E0E0',
  },
  inputContainerDark: {
    backgroundColor: '#1E1E1E',
    borderTopColor: '#333333',
  },
  input: {
    flex: 1,
    borderWidth: 1,
    borderRadius: 20,
    paddingHorizontal: 16,
    paddingTop: Platform.OS === 'ios' ? 10 : 8, // Adjust padding for different platforms
    paddingBottom: Platform.OS === 'ios' ? 10 : 8,
    fontSize: 16,
    maxHeight: 100, // Limit input height
    fontFamily: 'Outfit-Regular', // Ensure font is loaded
    marginRight: 8, // Add margin between input and button
  },
  inputLight: {
    backgroundColor: '#F5F5F5',
    borderColor: '#E0E0E0',
    color: '#212121',
  },
  inputDark: {
    backgroundColor: '#2D2D2D',
    borderColor: '#444444', // Slightly lighter border in dark mode
    color: '#FFFFFF',
  },
  sendButton: {
    borderRadius: 22, // Make it perfectly round
    overflow: 'hidden',
    width: 44,
    height: 44,
    justifyContent: 'center',
    alignItems: 'center',
  },
  sendButtonDisabled: {
    opacity: 0.5,
  },
  sendButtonGradient: {
    width: '100%',
    height: '100%',
    justifyContent: 'center',
    alignItems: 'center',
  },
  messageActions: {
    position: 'absolute', // Position actions absolutely
    bottom: 5,
    right: 50, // Position next to timestamp
    flexDirection: 'row',
    alignItems: 'center',
  },
  actionButton: {
    padding: 4,
    marginLeft: 6, // Space between action buttons
  },
});