import { Tabs } from 'expo-router';
import { LinearGradient } from 'expo-linear-gradient';
import { StyleSheet, View } from 'react-native';
import { Camera, Sparkles } from 'lucide-react-native';
import { useTheme } from '@/context/ThemeContext';

export default function TabLayout() {
  const { theme } = useTheme();
  const isDark = theme === 'dark';

  return (
    <Tabs
      screenOptions={{
        headerShown: false,
        tabBarActiveTintColor: isDark ? '#BB86FC' : '#6200EE',
        tabBarInactiveTintColor: isDark ? '#9E9E9E' : '#757575',
        tabBarShowLabel: true,
        tabBarLabelStyle: {
          fontFamily: 'Outfit-SemiBold',
          fontSize: 12,
        },
        tabBarStyle: {
          borderTopWidth: 0,
          elevation: 0,
          height: 60,
          backgroundColor: isDark ? '#121212' : '#FFFFFF',
        },
        tabBarBackground: () => (
          <View style={styles.tabBarContainer}>
            <LinearGradient
              colors={isDark ? ['#121212', '#1E1E1E'] : ['#FFFFFF', '#F5F5F5']}
              style={styles.gradient}
            />
          </View>
        ),
      }}>
      <Tabs.Screen
        name="index"
        options={{
          title: 'Chat',
          tabBarIcon: ({ color, size }) => (
            <Sparkles size={size} color={color} />
          ),
        }}
      />
      <Tabs.Screen
        name="analyze"
        options={{
          title: 'Analyze',
          tabBarIcon: ({ color, size }) => (
            <Camera size={size} color={color} />
          ),
        }}
      />
    </Tabs>
  );
}

const styles = StyleSheet.create({
  tabBarContainer: {
    width: '100%',
    height: '100%',
    position: 'absolute',
  },
  gradient: {
    width: '100%',
    height: '100%',
  },
});