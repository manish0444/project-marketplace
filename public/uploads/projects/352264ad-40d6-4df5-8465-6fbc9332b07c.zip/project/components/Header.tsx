import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { useRouter } from 'expo-router';
import { ThumbsUp, Sun, Moon, Heart } from 'lucide-react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useTheme } from '@/context/ThemeContext';

interface HeaderProps {
  title: string;
  showFavorites?: boolean;
}

export default function Header({ title, showFavorites = false }: HeaderProps) {
  const router = useRouter();
  const { theme, toggleTheme } = useTheme();
  const isDark = theme === 'dark';

  const goToFavorites = () => {
    // In a real app, this would navigate to a favorites screen
    console.log('Navigate to favorites');
  };

  return (
    <SafeAreaView edges={['top']} style={styles.safeArea}>
      <LinearGradient
        colors={isDark ? ['#1A1A1A', '#121212'] : ['#FFFFFF', '#F5F5F5']}
        style={styles.gradientHeader}
      >
        <View style={styles.headerContainer}>
          <View style={styles.titleContainer}>
            <ThumbsUp
              size={24}
              color={isDark ? '#BB86FC' : '#6200EE'}
              style={styles.logo}
            />
            <Text style={[
              styles.title,
              isDark ? styles.titleDark : styles.titleLight
            ]}>
              {title}
            </Text>
          </View>
          
          <View style={styles.actionButtons}>
            {showFavorites && (
              <TouchableOpacity
                style={[styles.iconButton, styles.heartButton]}
                onPress={goToFavorites}
              >
                <Heart
                  size={24}
                  color={isDark ? '#BB86FC' : '#6200EE'}
                />
              </TouchableOpacity>
            )}
            
            <TouchableOpacity
              style={styles.iconButton}
              onPress={toggleTheme}
            >
              {isDark ? (
                <Sun size={24} color="#FFC107" />
              ) : (
                <Moon size={24} color="#6200EE" />
              )}
            </TouchableOpacity>
          </View>
        </View>
      </LinearGradient>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    backgroundColor: 'transparent',
  },
  gradientHeader: {
    paddingHorizontal: 16,
    paddingVertical: 12,
  },
  headerContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  titleContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  logo: {
    marginRight: 8,
  },
  title: {
    fontSize: 20,
    fontFamily: 'Outfit-Bold',
  },
  titleLight: {
    color: '#212121',
  },
  titleDark: {
    color: '#FFFFFF',
  },
  actionButtons: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  iconButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
    marginLeft: 8,
  },
  heartButton: {
    marginRight: 4,
  },
});