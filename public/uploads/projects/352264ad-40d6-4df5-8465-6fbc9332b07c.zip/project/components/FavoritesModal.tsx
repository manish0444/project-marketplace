import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  FlatList,
  Modal,
  Platform,
} from 'react-native';
import { X, Copy } from 'lucide-react-native';
import { useTheme } from '@/context/ThemeContext';

interface FavoritesModalProps {
  visible: boolean;
  onClose: () => void;
  favorites: string[];
  onCopyFavorite: (text: string) => void;
}

export default function FavoritesModal({
  visible,
  onClose,
  favorites,
  onCopyFavorite,
}: FavoritesModalProps) {
  const { theme } = useTheme();
  const isDark = theme === 'dark';

  const renderFavoriteItem = ({ item }: { item: string }) => (
    <View style={[
      styles.favoriteItem,
      isDark ? styles.favoriteItemDark : styles.favoriteItemLight
    ]}>
      <Text style={[
        styles.favoriteText,
        isDark ? styles.textDark : styles.textLight
      ]}>
        {item}
      </Text>
      <TouchableOpacity
        style={styles.copyButton}
        onPress={() => onCopyFavorite(item)}
      >
        <Copy size={18} color={isDark ? '#BB86FC' : '#6200EE'} />
      </TouchableOpacity>
    </View>
  );

  return (
    <Modal
      visible={visible}
      transparent={true}
      animationType="slide"
      onRequestClose={onClose}
    >
      <View style={styles.modalOverlay}>
        <View style={[
          styles.modalContainer,
          isDark ? styles.modalContainerDark : styles.modalContainerLight
        ]}>
          <View style={styles.modalHeader}>
            <Text style={[
              styles.modalTitle,
              isDark ? styles.textDark : styles.textLight
            ]}>
              Favorite Lines
            </Text>
            <TouchableOpacity
              style={styles.closeButton}
              onPress={onClose}
            >
              <X size={24} color={isDark ? '#FFFFFF' : '#212121'} />
            </TouchableOpacity>
          </View>

          {favorites.length > 0 ? (
            <FlatList
              data={favorites}
              renderItem={renderFavoriteItem}
              keyExtractor={(item, index) => `favorite-${index}`}
              contentContainerStyle={styles.favoritesList}
            />
          ) : (
            <View style={styles.emptyContainer}>
              <Text style={[
                styles.emptyText,
                isDark ? { color: '#9E9E9E' } : { color: '#757575' }
              ]}>
                You don't have any favorite lines yet. Heart a line in the chat to save it here!
              </Text>
            </View>
          )}
        </View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'center',
    alignItems: 'center',
    ...Platform.select({
      web: {
        paddingTop: 50,
      },
    }),
  },
  modalContainer: {
    width: '90%',
    maxWidth: 500,
    borderRadius: 16,
    overflow: 'hidden',
    maxHeight: '80%',
    ...Platform.select({
      ios: {
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.25,
        shadowRadius: 3.84,
      },
      android: {
        elevation: 5,
      },
      web: {
        boxShadow: '0px 2px 10px rgba(0, 0, 0, 0.1)',
      },
    }),
  },
  modalContainerLight: {
    backgroundColor: '#FFFFFF',
  },
  modalContainerDark: {
    backgroundColor: '#1E1E1E',
  },
  modalHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 16,
    borderBottomWidth: 1,
  },
  modalHeaderLight: {
    borderBottomColor: '#E0E0E0',
  },
  modalHeaderDark: {
    borderBottomColor: '#333333',
  },
  modalTitle: {
    fontSize: 18,
    fontFamily: 'Outfit-Bold',
  },
  textLight: {
    color: '#212121',
  },
  textDark: {
    color: '#FFFFFF',
  },
  closeButton: {
    padding: 4,
  },
  favoritesList: {
    padding: 16,
  },
  favoriteItem: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 12,
    borderRadius: 8,
    marginBottom: 8,
  },
  favoriteItemLight: {
    backgroundColor: '#F5F5F5',
  },
  favoriteItemDark: {
    backgroundColor: '#2D2D2D',
  },
  favoriteText: {
    flex: 1,
    fontSize: 16,
    fontFamily: 'Outfit-Regular',
    paddingRight: 8,
  },
  copyButton: {
    padding: 8,
  },
  emptyContainer: {
    padding: 24,
    alignItems: 'center',
    justifyContent: 'center',
  },
  emptyText: {
    fontSize: 16,
    textAlign: 'center',
    fontFamily: 'Outfit-Regular',
    lineHeight: 24,
  },
});